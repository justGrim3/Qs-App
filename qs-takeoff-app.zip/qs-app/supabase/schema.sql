-- Run this once in Supabase: Dashboard → SQL Editor → New query → paste all → Run.

create table projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  sections jsonb not null default '["Substructure","Superstructure — Frame","Superstructure — Envelope","Internal finishes","Services","External works"]',
  created_by uuid references auth.users not null,
  created_at timestamptz not null default now()
);

-- Every project has one or more members. Today, every project gets exactly
-- one row (its creator, role 'owner'). Stage 2 (sharing with colleagues) just
-- inserts more rows here with role 'editor' — no schema change needed.
create table project_members (
  project_id uuid references projects on delete cascade not null,
  user_id uuid references auth.users not null,
  role text not null default 'owner',
  primary key (project_id, user_id)
);

create table dimension_rows (
  id uuid primary key default gen_random_uuid(),
  project_id uuid references projects on delete cascade not null,
  section text not null,
  timesing numeric not null default 1,
  dims jsonb not null default '[]',
  squaring numeric not null,
  description text not null,
  unit text not null,
  drawing_ref text,
  created_at timestamptz not null default now()
);

-- Personal rate list, shared across all of one user's own projects.
create table rates (
  owner uuid references auth.users not null,
  description text not null,
  unit text not null,
  rate numeric not null default 0,
  primary key (owner, description, unit)
);

-- Auto-add the creator as 'owner' the moment a project is created,
-- so the app never has to insert into project_members itself.
create or replace function public.handle_new_project()
returns trigger as $$
begin
  insert into project_members (project_id, user_id, role)
  values (new.id, auth.uid(), 'owner');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_project_created
after insert on projects
for each row execute function handle_new_project();

alter table projects enable row level security;
alter table project_members enable row level security;
alter table dimension_rows enable row level security;
alter table rates enable row level security;

create policy "member can see project" on projects for select using (
  id in (select project_id from project_members where user_id = auth.uid())
);
create policy "creator can insert project" on projects for insert with check (created_by = auth.uid());
create policy "member can update project" on projects for update using (
  id in (select project_id from project_members where user_id = auth.uid())
);
create policy "owner can delete project" on projects for delete using (
  id in (select project_id from project_members where user_id = auth.uid() and role = 'owner')
);

create policy "see own membership rows" on project_members for select using (user_id = auth.uid());

create policy "member can read rows" on dimension_rows for select using (
  project_id in (select project_id from project_members where user_id = auth.uid())
);
create policy "member can write rows" on dimension_rows for insert with check (
  project_id in (select project_id from project_members where user_id = auth.uid())
);
create policy "member can update rows" on dimension_rows for update using (
  project_id in (select project_id from project_members where user_id = auth.uid())
);
create policy "member can delete rows" on dimension_rows for delete using (
  project_id in (select project_id from project_members where user_id = auth.uid())
);

create policy "own rates" on rates for all using (owner = auth.uid()) with check (owner = auth.uid());
