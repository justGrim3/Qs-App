# Dimension Sheet — real app

Next.js + Supabase. No terminal needed to deploy — everything below is done
through websites in your tablet's browser.

## 1. Supabase (database + accounts) — 5 minutes

1. Go to supabase.com → New project. Pick any name/region, set a database password (save it somewhere).
2. In the left sidebar: **SQL Editor** → New query.
3. Open `supabase/schema.sql` from this project, copy all of it, paste it in, click **Run**.
4. Left sidebar → **Authentication → Providers** → make sure Email is on.
   - Optional but recommended while testing: **Authentication → Settings** → turn OFF "Confirm email", so you can sign up and use the app immediately without checking an inbox. Turn it back on before real users sign up.
5. Left sidebar → **Project Settings → API**. Copy two values, you'll need them in step 3:
   - **Project URL**
   - **anon public** key

## 2. GitHub (put the code somewhere Vercel can see it)

1. Go to github.com → New repository → name it (e.g. `qs-takeoff`) → Create.
2. On the new repo's page, press the **.** key (or change the URL from
   `github.com/...` to `github.dev/...`) — this opens a full code editor in
   your browser, no install needed.
3. In the file explorer on the left, recreate this project's folders and
   files, pasting each file's contents in. (Right-click in the explorer →
   there's also an **Upload...** option if your tablet lets you pick multiple
   files/folders at once from the download below.)
4. Commit (there's a Source Control icon in the left rail — write any message,
   click the checkmark) and it saves straight to GitHub.

## 3. Vercel (hosting)

1. Go to vercel.com → New Project → **Import** your GitHub repo.
2. Before deploying, open **Environment Variables** and add:
   - `NEXT_PUBLIC_SUPABASE_URL` = the Project URL from step 1
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = the anon public key from step 1
3. Click **Deploy**. A couple of minutes later you'll have a real URL with
   working `/login`, `/dashboard`, `/projects/...` pages.

## What's included vs. what's next

This is the stage-1 (just you) version: accounts, projects, the dimension
sheet, standard-item checklist, abstract with your rate list, and CSV/PDF
export — all synced to the database instead of one browser's storage.

Not ported yet, on purpose, so this stayed a manageable first step:
- Drawing import + click-to-measure
- The "Count items" and reassign tools from the prototype

The database is already built for stage 2 (sharing a project with a
colleague): `project_members` just needs an "invite" action added later that
inserts another row — no schema change required.
